-- 02_analysis.sql
-- Core product analytics queries.

-- A. Activation within 7 days of signup
WITH first_activation AS (
    SELECT
        u.user_id,
        u.signup_date,
        e.variant,
        MIN(e.event_timestamp::date) AS activation_date
    FROM analytics.users_clean u
    JOIN analytics.experiment_clean e
      ON u.user_id = e.user_id
    JOIN analytics.events_clean ev
      ON u.user_id = ev.user_id
     AND ev.event_name = 'onboarding_completed'
     AND ev.event_timestamp::date BETWEEN u.signup_date
                                      AND u.signup_date + 7
    GROUP BY 1,2,3
)
SELECT
    variant,
    COUNT(DISTINCT user_id) AS activated_users,
    ROUND(
        100.0 * COUNT(DISTINCT user_id)
        / SUM(COUNT(DISTINCT user_id)) OVER (PARTITION BY variant),
        2
    ) AS note_do_not_use_for_rate
FROM first_activation
GROUP BY variant;

-- Better activation-rate query:
WITH cohort AS (
    SELECT
        u.user_id,
        x.variant,
        EXISTS (
            SELECT 1
            FROM analytics.events_clean ev
            WHERE ev.user_id = u.user_id
              AND ev.event_name = 'onboarding_completed'
              AND ev.event_timestamp::date BETWEEN u.signup_date
                                               AND u.signup_date + 7
        ) AS activated_7d
    FROM analytics.users_clean u
    JOIN analytics.experiment_clean x USING (user_id)
)
SELECT
    variant,
    COUNT(*) AS users,
    SUM(activated_7d::int) AS activated_users,
    ROUND(100.0 * AVG(activated_7d::int), 2) AS activation_rate_pct
FROM cohort
GROUP BY variant
ORDER BY variant;

-- B. Feature adoption among activated users
WITH activated AS (
    SELECT DISTINCT u.user_id
    FROM analytics.users_clean u
    JOIN analytics.events_clean e USING (user_id)
    WHERE e.event_name = 'onboarding_completed'
      AND e.event_timestamp::date BETWEEN u.signup_date AND u.signup_date + 7
),
features AS (
    SELECT 'Budget' AS feature_name, 'create_budget' AS event_name
    UNION ALL SELECT 'Card Wallet', 'card_added_to_wallet'
    UNION ALL SELECT 'Transfers', 'transfer_completed'
    UNION ALL SELECT 'Bill Pay', 'billpay_completed'
    UNION ALL SELECT 'Mobile Deposit', 'deposit_completed'
)
SELECT
    f.feature_name,
    COUNT(DISTINCT CASE WHEN e.event_name = f.event_name THEN a.user_id END) AS adopters,
    ROUND(
        100.0 * COUNT(DISTINCT CASE WHEN e.event_name = f.event_name THEN a.user_id END)
        / COUNT(DISTINCT a.user_id), 2
    ) AS adoption_rate_pct
FROM activated a
CROSS JOIN features f
LEFT JOIN analytics.events_clean e
  ON e.user_id = a.user_id
GROUP BY f.feature_name
ORDER BY adoption_rate_pct DESC;

-- C. 30-day retention by signup cohort
WITH cohort AS (
    SELECT
        u.user_id,
        DATE_TRUNC('month', u.signup_date)::date AS cohort_month,
        EXISTS (
            SELECT 1
            FROM analytics.events_clean e
            WHERE e.user_id = u.user_id
              AND e.event_timestamp::date BETWEEN u.signup_date + 21
                                               AND u.signup_date + 30
              AND e.event_name IN ('app_open','login','view_dashboard')
        ) AS retained_30d
    FROM analytics.users_clean u
)
SELECT
    cohort_month,
    COUNT(*) AS cohort_users,
    SUM(retained_30d::int) AS retained_users,
    ROUND(100.0 * AVG(retained_30d::int), 2) AS retention_rate_pct
FROM cohort
GROUP BY cohort_month
ORDER BY cohort_month;

-- D. Retention by feature adoption
WITH feature_use AS (
    SELECT
        u.user_id,
        MAX(CASE WHEN e.event_name = 'create_budget' THEN 1 ELSE 0 END) AS used_budget,
        MAX(CASE WHEN e.event_name = 'card_added_to_wallet' THEN 1 ELSE 0 END) AS used_wallet,
        MAX(CASE WHEN e.event_name = 'transfer_completed' THEN 1 ELSE 0 END) AS used_transfers,
        MAX(CASE WHEN e.event_name = 'billpay_completed' THEN 1 ELSE 0 END) AS used_billpay
    FROM analytics.users_clean u
    LEFT JOIN analytics.events_clean e USING (user_id)
    GROUP BY u.user_id
),
retention AS (
    SELECT
        u.user_id,
        EXISTS (
            SELECT 1
            FROM analytics.events_clean e
            WHERE e.user_id = u.user_id
              AND e.event_timestamp::date BETWEEN u.signup_date + 21
                                               AND u.signup_date + 30
              AND e.event_name IN ('app_open','login','view_dashboard')
        ) AS retained_30d
    FROM analytics.users_clean u
)
SELECT
    CASE
        WHEN f.used_budget + f.used_wallet + f.used_transfers + f.used_billpay = 0 THEN '0 features'
        WHEN f.used_budget + f.used_wallet + f.used_transfers + f.used_billpay = 1 THEN '1 feature'
        WHEN f.used_budget + f.used_wallet + f.used_transfers + f.used_billpay = 2 THEN '2 features'
        ELSE '3+ features'
    END AS feature_adoption_band,
    COUNT(*) AS users,
    ROUND(100.0 * AVG(r.retained_30d::int), 2) AS retention_rate_pct
FROM feature_use f
JOIN retention r USING (user_id)
GROUP BY 1
ORDER BY 1;

-- E. Experiment guardrail: transaction activity
SELECT
    x.variant,
    COUNT(DISTINCT u.user_id) AS users,
    COUNT(DISTINCT t.transaction_id) AS transactions,
    ROUND(
        COUNT(DISTINCT t.transaction_id)::numeric
        / NULLIF(COUNT(DISTINCT u.user_id),0), 2
    ) AS transactions_per_user,
    ROUND(AVG(t.amount), 2) AS avg_transaction_amount
FROM analytics.users_clean u
JOIN analytics.experiment_clean x USING (user_id)
LEFT JOIN analytics.transactions_clean t
  ON u.user_id = t.user_id
GROUP BY x.variant
ORDER BY x.variant;
