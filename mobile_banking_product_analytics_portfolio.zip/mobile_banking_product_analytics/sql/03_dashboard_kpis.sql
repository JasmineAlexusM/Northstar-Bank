-- 03_dashboard_kpis.sql
SELECT
    COUNT(DISTINCT u.user_id) AS total_users,
    COUNT(DISTINCT CASE
        WHEN EXISTS (
            SELECT 1 FROM analytics.events_clean e
            WHERE e.user_id = u.user_id
              AND e.event_name = 'onboarding_completed'
              AND e.event_timestamp::date BETWEEN u.signup_date AND u.signup_date + 7
        ) THEN u.user_id END
    ) AS activated_users,
    COUNT(DISTINCT t.user_id) AS transacting_users,
    ROUND(AVG(t.amount),2) AS avg_transaction_amount
FROM analytics.users_clean u
LEFT JOIN analytics.transactions_clean t USING (user_id);
