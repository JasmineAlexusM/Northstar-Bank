-- PostgreSQL schema for the raw and analytical layers.

CREATE SCHEMA IF NOT EXISTS raw;
CREATE SCHEMA IF NOT EXISTS analytics;

CREATE TABLE IF NOT EXISTS raw.users (
    user_id BIGINT,
    signup_date DATE,
    age INTEGER,
    region TEXT,
    device_type TEXT,
    acquisition_channel TEXT,
    income_band TEXT,
    account_tenure_months INTEGER
);

CREATE TABLE IF NOT EXISTS raw.experiment_assignments (
    user_id BIGINT,
    experiment_name TEXT,
    variant TEXT,
    assignment_date DATE
);

CREATE TABLE IF NOT EXISTS raw.app_events (
    event_id BIGINT,
    user_id BIGINT,
    event_timestamp TIMESTAMP,
    event_name TEXT,
    device_type TEXT,
    region TEXT,
    variant TEXT
);

CREATE TABLE IF NOT EXISTS raw.financial_transactions (
    transaction_id BIGINT,
    user_id BIGINT,
    transaction_timestamp TIMESTAMP,
    transaction_type TEXT,
    merchant_category TEXT,
    amount NUMERIC(12,2),
    direction TEXT
);
