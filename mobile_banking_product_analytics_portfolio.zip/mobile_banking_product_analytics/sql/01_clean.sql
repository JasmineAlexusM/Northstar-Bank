-- 01_clean.sql
-- Cleans raw exports and creates analysis-ready tables.

DROP TABLE IF EXISTS analytics.users_clean;
CREATE TABLE analytics.users_clean AS
SELECT
    user_id,
    signup_date,
    age,
    INITCAP(TRIM(region)) AS region,
    COALESCE(NULLIF(TRIM(device_type), ''), 'Unknown') AS device_type,
    INITCAP(TRIM(acquisition_channel)) AS acquisition_channel,
    income_band,
    account_tenure_months
FROM raw.users
WHERE user_id IS NOT NULL
  AND signup_date BETWEEN DATE '2025-01-01' AND DATE '2025-12-31'
  AND age BETWEEN 18 AND 100;

DROP TABLE IF EXISTS analytics.experiment_clean;
CREATE TABLE analytics.experiment_clean AS
SELECT DISTINCT ON (user_id, experiment_name)
    user_id,
    experiment_name,
    INITCAP(TRIM(variant)) AS variant,
    assignment_date
FROM raw.experiment_assignments
WHERE user_id IS NOT NULL
  AND experiment_name = 'onboarding_v2'
ORDER BY user_id, experiment_name, assignment_date;

DROP TABLE IF EXISTS analytics.events_clean;
CREATE TABLE analytics.events_clean AS
SELECT DISTINCT ON (event_id)
    event_id,
    user_id,
    event_timestamp,
    LOWER(TRIM(event_name)) AS event_name,
    INITCAP(TRIM(device_type)) AS device_type,
    INITCAP(TRIM(region)) AS region,
    INITCAP(TRIM(variant)) AS variant
FROM raw.app_events
WHERE event_id IS NOT NULL
  AND user_id IS NOT NULL
  AND event_timestamp BETWEEN TIMESTAMP '2025-01-01 00:00:00'
                          AND TIMESTAMP '2025-12-31 23:59:59'
  AND event_name IS NOT NULL
ORDER BY event_id, event_timestamp;

DROP TABLE IF EXISTS analytics.transactions_clean;
CREATE TABLE analytics.transactions_clean AS
SELECT DISTINCT ON (transaction_id)
    transaction_id,
    user_id,
    transaction_timestamp,
    INITCAP(TRIM(transaction_type)) AS transaction_type,
    COALESCE(INITCAP(TRIM(merchant_category)), 'Other') AS merchant_category,
    amount::NUMERIC(12,2) AS amount,
    INITCAP(TRIM(direction)) AS direction
FROM raw.financial_transactions
WHERE transaction_id IS NOT NULL
  AND user_id IS NOT NULL
  AND transaction_timestamp BETWEEN TIMESTAMP '2025-01-01 00:00:00'
                                AND TIMESTAMP '2025-12-31 23:59:59'
  AND amount > 0
ORDER BY transaction_id, transaction_timestamp;
