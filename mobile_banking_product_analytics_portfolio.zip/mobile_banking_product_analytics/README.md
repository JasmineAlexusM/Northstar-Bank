# Mobile Banking Product Analytics: Activation, Feature Adoption & Retention

## Project Overview

This portfolio project analyzes a synthetic mobile-banking product dataset to answer a realistic product analytics question:

> **How does onboarding performance relate to feature adoption and early customer retention, and what changed after the introduction of a new onboarding experience?**

The project follows a complete analytics workflow:

**Business question → data cleaning → SQL transformation → exploratory analysis → funnel/cohort analysis → experiment analysis → product recommendations**

The dataset is synthetic and contains intentionally messy records so the workflow demonstrates practical data-cleaning skills rather than analysis of a perfectly prepared dataset.

---

## Business Context

A fictional digital banking company, **Northstar Bank**, launched a new version of its mobile-app onboarding experience during 2025.

The product team wants to understand:

1. How many new users become activated within 7 days?
2. Did the new onboarding experience change 7-day activation?
3. Which product features are adopted by activated users?
4. How does feature adoption relate to 30-day retention?
5. Are there meaningful differences in transaction activity between onboarding variants?
6. What should the product team investigate next?

### Important analytical distinction

The onboarding comparison is based on an experiment assignment, so activation differences can be evaluated as an experiment result within the synthetic design. The feature-adoption and retention relationships are observational and should not be interpreted as causal.

---

## Dataset

The project contains four raw tables.

| Table | Approx. rows | Grain | Purpose |
|---|---:|---|---|
| `users_raw.csv` | 15,020 | 1 row/user + intentional duplicates | Customer attributes |
| `experiment_assignments_raw.csv` | 15,030 | 1 row/user + intentional duplicates | Onboarding experiment assignment |
| `app_events_raw.csv` | 337,318 | 1 row/event | Product usage and engagement |
| `financial_transactions_raw.csv` | 45,494 | 1 row/transaction + intentional duplicates | Banking transaction activity |

### Key fields

**Users**
- `user_id`
- `signup_date`
- `age`
- `region`
- `device_type`
- `acquisition_channel`
- `income_band`
- `account_tenure_months`

**App events**
- `event_id`
- `user_id`
- `event_timestamp`
- `event_name`
- `device_type`
- `region`
- `variant`

**Experiment**
- `experiment_name`
- `variant`
- `assignment_date`

**Transactions**
- `transaction_id`
- `transaction_timestamp`
- `transaction_type`
- `merchant_category`
- `amount`
- `direction`

---

## Why the Dataset Is Realistic

The synthetic data was designed to mimic patterns commonly encountered in product analytics:

- Different acquisition channels have different customer mixes.
- iOS and Android users are represented in different proportions.
- Engagement varies substantially between users.
- Activated users generate more downstream product activity.
- Feature adoption is uneven rather than uniformly distributed.
- User activity decays after signup.
- Retention varies by signup cohort.
- Higher-engagement users generate more transactions.
- The onboarding treatment produces a modest activation improvement rather than an unrealistic jump.
- Raw exports include duplicates, missing values, inconsistent capitalization/spacing, invalid amounts, and an out-of-period timestamp.

This allows the project to demonstrate both **data engineering fundamentals and product analytics reasoning**.

---

## Data Cleaning

The raw data is intentionally imperfect.

The SQL cleaning layer:

- Removes duplicate user/event/transaction records.
- Standardizes capitalization and whitespace.
- Handles missing device types.
- Replaces missing merchant categories.
- Removes invalid negative transaction amounts.
- Removes timestamps outside the 2025 analysis period.
- Keeps only valid user IDs.
- Creates analysis-ready tables in an `analytics` schema.

See:

- `sql/00_schema.sql`
- `sql/01_clean.sql`

---

## Product Metrics

### 1. 7-Day Activation

A user is considered activated when they complete onboarding within seven days of signup.

**Formula**

`7-Day Activation Rate = Users completing onboarding within 7 days / Eligible new users`

### 2. Feature Adoption

Feature adoption measures the percentage of activated users who completed a meaningful feature event such as:

- Creating a budget
- Adding a card to a digital wallet
- Completing a transfer
- Completing bill pay
- Completing a mobile deposit

### 3. 30-Day Retention

A user is classified as retained when they perform a core app activity during days 21–30 after signup.

Core activity includes:

- `app_open`
- `login`
- `view_dashboard`

This definition intentionally focuses on meaningful return behavior rather than simply counting any event.

---

## Experiment Analysis

The synthetic onboarding experiment produced the following 7-day activation rates:

| Variant | 7-Day Activation |
|---|---:|
| Control | 8.6% |
| Treatment | 11.5% |

The treatment-control difference is approximately **2.9 percentage points**, equivalent to a relative difference of approximately **33.9%**.

### Interpretation

The treatment group shows a measurable difference in activation in this synthetic experiment.

The appropriate next step would be to validate statistical significance, examine confidence intervals, check experiment balance, and evaluate guardrail metrics before making a production rollout decision.

This project deliberately does **not** treat activation lift alone as sufficient evidence for a product decision.

---

## Feature Adoption Findings

Among users who activated within seven days, feature adoption was:

| Feature | Adoption |
|---|---:|
| Card Wallet | 32.0% |
| Mobile Deposit | 30.6% |
| Transfers | 30.6% |
| Budget | 30.2% |
| Bill Pay | 30.0% |

### Product interpretation

The adoption distribution shows that activation is only the beginning of the product journey.

Some features are substantially more frequently used than others. This creates several product questions:

- Are low-adoption features difficult to discover?
- Are they poorly positioned in onboarding?
- Do users understand their value?
- Are there eligibility constraints?
- Does adoption differ by acquisition channel or device?
- Which features are associated with repeat usage?

---

## Retention Analysis

The 30-day retention rate is calculated using core activity during days 21–30 after signup.

Retention varies across signup cohorts, with the cohort-level results shown in the EDA chart.

A useful product-analytics follow-up is to compare retention across:

- onboarding variant
- acquisition channel
- device
- feature-adoption level
- number of sessions
- transaction activity

### Feature breadth and retention

Descriptively, the synthetic data also shows variation in retention by the number of distinct product features used:

- **0 feature(s):** 42.0% 30-day retention
- **1 feature(s):** 48.9% 30-day retention
- **2 feature(s):** 54.7% 30-day retention
- **3 feature(s):** 62.4% 30-day retention
- **4 feature(s):** 68.6% 30-day retention
- **5 feature(s):** 75.0% 30-day retention

This is an **association, not proof of causation**. Highly engaged customers may simply be more likely both to adopt multiple features and to return to the app.

---

## Transaction Behavior

Transaction activity adds a financial-services dimension to the product analysis.

The dataset contains:

- **Card Purchase:** 26,120.0 transactions
- **ACH Transfer:** 6,338.0 transactions
- **Bill Pay:** 5,312.0 transactions
- **Direct Deposit:** 3,999.0 transactions
- **ATM Withdrawal:** 3,663.0 transactions

Transaction behavior can be used as a downstream engagement signal and as a guardrail when evaluating product changes.

---

## EDA Visualizations

The Python script generates:

1. Monthly new-user signups
2. 7-day activation by onboarding variant
3. Feature adoption among activated users
4. 30-day retention by signup cohort
5. Transaction volume by transaction type

Run:

```bash
pip install -r requirements.txt
python python/01_eda.py
```

Charts will be written to:

```text
docs/charts/
```

---

## SQL Analysis

The core SQL analysis includes:

### Activation
Calculates 7-day activation by experiment variant.

### Feature adoption
Measures adoption of high-value product features among activated users.

### Cohort retention
Calculates 30-day retention by monthly signup cohort.

### Feature breadth
Compares retention across users with different levels of product adoption.

### Experiment guardrails
Compares transaction activity and average transaction amount between variants.

See:

```text
sql/02_analysis.sql
```

---

## Suggested Dashboard

A Tableau or Power BI dashboard could contain four sections.

### Executive KPI Row
- New users
- 7-day activation
- 30-day retention
- Transacting users
- Average transaction amount

### Onboarding Funnel
`Signup → Onboarding Started → Step Completed → Onboarding Completed`

### Product Adoption
Feature adoption by:
- feature
- device
- acquisition channel
- onboarding variant

### Retention
- cohort retention
- retention by feature breadth
- retention by acquisition channel

A filter panel could include:

- Signup month
- Variant
- Device
- Region
- Acquisition channel
- Income band

---

## Recommended Statistical Extensions

To take this project beyond basic dashboarding, the next analytical layer would be:

### Experiment significance
Test the difference in 7-day activation between control and treatment using a two-proportion z-test or equivalent confidence interval.

### Effect size
Report:

- absolute percentage-point difference
- relative lift
- 95% confidence interval

### Segmentation
Check whether activation differs by:

- device
- acquisition channel
- region
- income band

### Retention modeling
Use logistic regression to model 30-day retention using:

- activation
- feature adoption
- acquisition channel
- device
- engagement
- experiment variant

The model should be interpreted as an explanatory/associational model unless the design supports causal inference.

---

## Business Questions This Project Demonstrates

This portfolio project demonstrates the ability to move from raw data to product decisions:

**Raw data**
→ SQL cleaning  
→ metric definitions  
→ exploratory analysis  
→ segmentation  
→ funnel analysis  
→ cohort analysis  
→ experiment analysis  
→ business interpretation

The central product question is not simply:

> "What happened?"

It is:

> **"What changed, where did it change, and what should the product team investigate next?"**

---

## Tools

- **SQL / PostgreSQL** — data cleaning, joins, CTEs, metric construction
- **Python** — pandas, NumPy, matplotlib
- **Product Analytics** — activation, feature adoption, retention, cohorts, experiment analysis
- **BI** — Tableau or Power BI can be added as the visualization layer
- **GitHub** — documentation and reproducible project structure

---

## Repository Structure

```text
mobile_banking_product_analytics/
│
├── data/
│   ├── raw/
│   │   ├── users_raw.csv
│   │   ├── experiment_assignments_raw.csv
│   │   ├── app_events_raw.csv
│   │   └── financial_transactions_raw.csv
│   │
│   └── clean/
│       ├── users_clean.csv
│       ├── experiment_assignments_clean.csv
│       ├── app_events_clean.csv
│       └── financial_transactions_clean.csv
│
├── sql/
│   ├── 00_schema.sql
│   ├── 01_clean.sql
│   ├── 02_analysis.sql
│   └── 03_dashboard_kpis.sql
│
├── python/
│   └── 01_eda.py
│
├── docs/
│   └── charts/
│
├── requirements.txt
└── README.md
```

---

## Portfolio Takeaway

This project demonstrates a product analytics workflow grounded in a realistic financial-services environment. Rather than presenting isolated charts, it connects customer behavior to product outcomes through measurable definitions of activation, feature adoption, retention, and transaction engagement.

The strongest portfolio story is the end-to-end workflow:

**Business problem → messy raw data → SQL transformation → Python EDA → product metrics → experiment analysis → retention analysis → actionable questions**

---

## Data Disclaimer

All customer records, events, transactions, experiment assignments, and business results in this repository are **synthetically generated for portfolio and educational purposes**. No real customer information is used.
