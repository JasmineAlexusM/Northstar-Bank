from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "clean"
OUT = ROOT / "docs" / "charts"
OUT.mkdir(parents=True, exist_ok=True)

users = pd.read_csv(DATA / "users_clean.csv", parse_dates=["signup_date"])
events = pd.read_csv(DATA / "app_events_clean.csv", parse_dates=["event_timestamp"])
tx = pd.read_csv(DATA / "financial_transactions_clean.csv", parse_dates=["transaction_timestamp"])
exp = pd.read_csv(DATA / "experiment_assignments_clean.csv", parse_dates=["assignment_date"])

# 1. Signup volume by month
signup = users.assign(month=users["signup_date"].dt.to_period("M").astype(str)).groupby("month").size()
plt.figure(figsize=(10,5))
signup.plot(kind="line", marker="o")
plt.title("Monthly New User Signups")
plt.xlabel("Signup month")
plt.ylabel("Users")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(OUT / "01_monthly_signups.png", dpi=160)
plt.close()

# 2. Activation by experiment variant
onboarding = events[events["event_name"].eq("onboarding_completed")][["user_id","event_timestamp"]].copy()
onboarding = onboarding.merge(users[["user_id","signup_date"]], on="user_id")
onboarding["days_to_activation"] = (
    onboarding["event_timestamp"].dt.normalize() - onboarding["signup_date"]
).dt.days
activated = onboarding[onboarding["days_to_activation"].between(0,7)].drop_duplicates("user_id")
activation = exp.merge(users[["user_id"]], on="user_id").assign(
    activated_7d=lambda d: d["user_id"].isin(activated["user_id"])
).groupby("variant")["activated_7d"].mean().mul(100)

plt.figure(figsize=(7,5))
activation.plot(kind="bar")
plt.title("7-Day Activation Rate by Onboarding Variant")
plt.xlabel("")
plt.ylabel("Activation rate (%)")
plt.xticks(rotation=0)
plt.ylim(0, max(activation.max()*1.25, 10))
plt.tight_layout()
plt.savefig(OUT / "02_activation_by_variant.png", dpi=160)
plt.close()

# 3. Feature adoption
feature_map = {
    "Budget": "create_budget",
    "Card Wallet": "card_added_to_wallet",
    "Transfers": "transfer_completed",
    "Bill Pay": "billpay_completed",
    "Mobile Deposit": "deposit_completed",
}
activated_ids = set(activated["user_id"])
feature_rates = {}
for feature, event_name in feature_map.items():
    adopters = set(events.loc[events["event_name"].eq(event_name), "user_id"])
    feature_rates[feature] = 100 * len(adopters & activated_ids) / max(len(activated_ids), 1)

feature_rates = pd.Series(feature_rates).sort_values()
plt.figure(figsize=(9,5))
feature_rates.plot(kind="barh")
plt.title("Feature Adoption Among 7-Day Activated Users")
plt.xlabel("Adoption rate (%)")
plt.ylabel("")
plt.tight_layout()
plt.savefig(OUT / "03_feature_adoption.png", dpi=160)
plt.close()

# 4. 30-day retention by signup cohort
daily_active = events[events["event_name"].isin(["app_open","login","view_dashboard"])][["user_id","event_timestamp"]]
daily_active["activity_date"] = daily_active["event_timestamp"].dt.normalize()
ret_rows = []
for _, row in users.iterrows():
    start = row["signup_date"]
    window = daily_active[
        (daily_active["user_id"].eq(row["user_id"])) &
        (daily_active["activity_date"].between(start + pd.Timedelta(days=21),
                                               start + pd.Timedelta(days=30)))
    ]
    ret_rows.append((row["user_id"], start.to_period("M"), int(len(window) > 0)))
ret = pd.DataFrame(ret_rows, columns=["user_id","cohort_month","retained_30d"])
cohort_ret = ret.groupby("cohort_month")["retained_30d"].mean().mul(100)

plt.figure(figsize=(10,5))
cohort_ret.plot(kind="line", marker="o")
plt.title("30-Day Retention by Signup Cohort")
plt.xlabel("Signup cohort")
plt.ylabel("Retention rate (%)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(OUT / "04_30d_retention.png", dpi=160)
plt.close()

# 5. Transaction mix
tx_mix = tx.groupby("transaction_type")["amount"].agg(["count","sum"]).sort_values("count")
plt.figure(figsize=(9,5))
tx_mix["count"].plot(kind="barh")
plt.title("Transaction Volume by Type")
plt.xlabel("Transaction count")
plt.ylabel("")
plt.tight_layout()
plt.savefig(OUT / "05_transaction_mix.png", dpi=160)
plt.close()

print("Charts saved to:", OUT)
