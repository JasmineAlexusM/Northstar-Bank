# Project Brief

**Company:** Northstar Bank (fictional)
**Industry:** Digital banking / fintech
**Period:** January–December 2025
**Primary objective:** Understand onboarding activation, product adoption, and early retention.

## Stakeholder
Product Manager, Mobile Banking

## Core Decision
Evaluate the onboarding experiment and identify downstream customer behaviors that merit deeper investigation.

## Primary KPIs
- 7-day activation
- Feature adoption
- 30-day retention
- Transacting users
- Transactions per user

## Guardrails
- Transaction volume per user
- Average transaction amount
- Support-chat activity
- Device mix / experiment balance

## Key Finding Snapshot
- Control activation: 8.6%
- Treatment activation: 11.5%
- Absolute activation difference: 2.9 percentage points
- Relative activation difference: 33.9%
- Highest-adoption feature: Card Wallet (32.0%)
