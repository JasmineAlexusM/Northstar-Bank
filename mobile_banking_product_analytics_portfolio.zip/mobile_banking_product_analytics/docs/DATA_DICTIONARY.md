# Data Dictionary

## users_raw.csv
| Column | Type | Description |
|---|---|---|
| user_id | integer | Unique customer identifier |
| signup_date | date | Customer signup date |
| age | integer | Customer age |
| region | text | Broad U.S. region |
| device_type | text | iOS or Android |
| acquisition_channel | text | Customer acquisition source |
| income_band | text | Approximate income segment |
| account_tenure_months | integer | Tenure measured at end of 2025 |

## experiment_assignments_raw.csv
| Column | Type | Description |
|---|---|---|
| user_id | integer | Customer identifier |
| experiment_name | text | Experiment name |
| variant | text | Control or Treatment |
| assignment_date | date | Experiment assignment date |

## app_events_raw.csv
| Column | Type | Description |
|---|---|---|
| event_id | integer | Unique event identifier |
| user_id | integer | Customer identifier |
| event_timestamp | timestamp | Event time |
| event_name | text | Product event |
| device_type | text | Device associated with event |
| region | text | Customer region |
| variant | text | Experiment variant |

## financial_transactions_raw.csv
| Column | Type | Description |
|---|---|---|
| transaction_id | integer | Unique transaction identifier |
| user_id | integer | Customer identifier |
| transaction_timestamp | timestamp | Transaction time |
| transaction_type | text | Banking transaction type |
| merchant_category | text | Merchant / transaction category |
| amount | decimal | Transaction amount |
| direction | text | Debit or Credit |
